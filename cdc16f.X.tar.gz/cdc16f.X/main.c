/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.3
        Device            :  PIC16F1455
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>
/*
                         Main application
 */

static uint8_t writeBuffer[64]; //Declaracion del buffer de salida
volatile char adcOK = 0, butOK = 0; //Banderas de control
volatile char butval, adcval; //Variables de lectura
void APPTasks(); //Prototipo del procedimiento APP
void USBTasks(void); //Prototipo del procedimiento USB
void main(void) //Programa principal
{
    SYSTEM_Initialize(); //Inicializa Puertos, Perifericos, etc
	INTERRUPT_GlobalInterruptEnable(); //Activa las interrupciones
    INTERRUPT_PeripheralInterruptEnable(); 
	ADC_SelectChannel(POT1); //Selecciona el canal de captura ADC
	TMR0_SetInterruptHandler(APPTasks); //Asigna la tarea ISR cada 1ms  
	while(1)
    {
		USBTasks(); //Ajecucion continua del procedimiento USB
    }
}
void APPTasks() //Procedimiento APP cada 1mS via ISR
{
	unsigned int val;
	static unsigned int but1cnt = 0, led1cnt = 0, adc1cnt = 0;
	//Inicio del Control para LED1
	led1cnt ++;
	if(led1cnt > 499) //cada 500ms
	{
		LED1_Toggle(); //Destella led
		led1cnt = 0;
	}
	//Inicio del Control para BUT1
	val = BUT1_GetValue(); //Lectura del pulsador BUT
	if(val != butval) //Solo si BUT cambia de estadoT
	{
		but1cnt ++;
		if(but1cnt > 199) //si mantiene por 200ms
		{
			butval = !butval; //Actuliza estado BUT
			butOK = 1; //Indica cambio de estado BUT
		}
	}
	else but1cnt = 0;
	//Inicio de Control para ADC
	adc1cnt ++;
	if(adc1cnt == 100) ADC_StartConversion(); //inicia en 100ms
	if((adc1cnt > 299) && ADC_IsConversionDone()) //Espera 200ms
	{
		val = (ADC_GetConversionResult() >> 6) / 10; //Lectura valor
 		if(val != adcval) //Si valor es diferente
		{
			adcval = val;
			adcOK = 1; //indica cambio de valor POT
		}
		adc1cnt = 0;
	}
}
void USBTasks(void)
{
    if( USBGetDeviceState() < CONFIGURED_STATE ) return;
    LED2_SetHigh(); //Activa LED1 cuendo USB esta configurado
	if(USBUSARTIsTxTrfReady()) //Si el Buffer de salida esta libre
    {
        if(butOK) //Verifica si hay cambio de estado BUT
		{
			butOK = 0;
			sprintf((char *) writeBuffer, "B:%u\n", butval);
			putUSBUSART(writeBuffer,4); //Envia mensaje
		}
		if(adcOK) //Verifica si hay cambio de estado POT
		{
			adcOK = 0;
			sprintf((char *) writeBuffer, "V:%03u\n", adcval);
			putUSBUSART(writeBuffer,6); //Envia mensaje
		}
    }
    CDCTxService(); //Procesa servicio USB
}

