#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    port = new QSerialPort();
    connect(port, SIGNAL(readyRead()), this, SLOT(readSerialPort()));
    foreach(const QSerialPortInfo &portinfo, QSerialPortInfo::availablePorts())
    {
        ui->comboBox->addItem(portinfo.systemLocation());
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::readSerialPort()
{
    QByteArray databytes;
    if(port->canReadLine()) //Espera el siguiente Texto VAL:347\r\n
    {
        databytes = port->readLine();
        QString msg(databytes);
        msg.remove(0,4); //Quita el texto "VAL:"
        ui->lcdNumber->display(msg.toInt()); //Muestra el valor
    }
}

void MainWindow::on_checkBox_stateChanged(int arg1)
{
    if(ui->checkBox->isChecked())
        {
            port->setPortName(ui->comboBox->currentText());
            port->setBaudRate(port->Baud9600, port->Input);
            port->setFlowControl(port->NoFlowControl);
            if(port->open(QIODevice::ReadOnly))
                ui->statusbar->showMessage("Puerto Conectado", 0);
            else
                ui->statusbar->showMessage("Error de conexion", 0);

        }
        else
        {
            if(port->isOpen())
            {
                port->close();
                ui->statusbar->showMessage("Puerto Desconectado", 5000);
            }
        }
}
