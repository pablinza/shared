#pragma config FOSC = INTRC_NOCLKOUT, WDTE = OFF, LVP = OFF
#include <stdio.h>
#include <xc.h>
#define _XTAL_FREQ 8000000
#define HX_DATpin PORTBbits.RB1 //Pin de salida DOUT									*
#define HX_SCKpin PORTBbits.RB0  //Pin de pulsos CLK 
#define LEDpin	PORTEbits.RE2 //Pin de salida LED
#define BUTpin	PORTBbits.RB2 //Pin del pulsador
unsigned long adcval = 0; //Registro de 32 bits
unsigned long HXReadvalue(); //Prototipo de funcion
unsigned long Dref = 531356L; //Valores por defecto
unsigned int  Diff = 8194;
void Ajuste();
void main()
{
	OSCCONbits.IRCF = 0b111; //Oscilador Interno a 8MHz Tcy 0.5u
	while(!OSCCONbits.HTS); //Espera hasta estabilizar INTOSC
	ANSEL = 0;	//Deshabilita los pines Analogicos ANS0-ANS7
	ANSELH = 0; //Deshabilita los pines Analogicos ANS8-ANS13
	TRISEbits.TRISE2 = 0; //Salida pin LED
	TRISBbits.TRISB0 = 0; //Pin CLK de salida
	TRISBbits.TRISB1 = 1; //Pin DOUT como entrada
	TRISBbits.TRISB2 = 1; //Pin RB2 como entrada pulsador
	OPTION_REGbits.nRBPU = 0; //Activa las Pullup del PORTB
	TXSTAbits.BRGH = 1;	//USART en modo de alta velocidad
    BAUDCTLbits.BRG16 = 0; //Generador de Baudios de 8-bit
    SPBRG = 52;	//Fosc/(16x(9600+1))
	TXSTAbits.TXEN = 1;	//Habilita el transmisor
	RCSTAbits.SPEN = 1; //Habilita el modulo USART
	while(1)
	{
		adcval = HXReadvalue();
		adcval &= 0x00FFFFFF; //Enmascara los 24bits
		adcval = adcval >> 4; //Descarta los �ltimos 4 bits
		if(adcval > Dref) //No debe ser menor a la Dref
			adcval = (adcval - Dref) * 140 / Diff; //Formula
		else adcval = 0;
		printf("GRM:%lu\r\n", adcval); //Muestra el valor
		__delay_ms(1000);
		LEDpin = !LEDpin; //Destello LED
		if(BUTpin == 0)
		{
			__delay_ms(50);
			if(BUTpin == 0)
			{
				while(BUTpin);
				Ajuste();
			}
		}
	}
}
void Ajuste() //Procedimiento para mostrar
{
	char paso = 0, loop = 1;
	printf("Retire Peso y presione BUT\r\n"); //Muestra el valor	
	while(loop)
	{
		adcval = HXReadvalue();
		adcval &= 0x00FFFFFF; //Max 8000000h set MSB to 0
		adcval >>= 4;
		printf("ADC:%lu\r\n", adcval); 
		__delay_ms(1000);
		if(BUTpin == 0) //Detecta si el pulsador es presionado
		{
			__delay_ms(50); //Espera un tiempo
			if(BUTpin == 0) //Confirma si el pulsador se mantiene presionado
			{
				while(BUTpin); //Espera hasta que se libere
				if(paso == 1) //Ocurre cuando se presiona por tercera vez
				{
					Diff = adcval - Dref; //Actualiza la variable de calculo
					printf("Ajuste final %06u", Diff);
					loop = 0;
				}
				if(paso == 0) //Ocurre cuando se presiona por segunda vez
				{
					Dref = adcval; //Actualiza la variable de calculo
					paso ++;
					printf("Coloque Peso y presione BUT\r\n");
				}
			}
		}
		
	}	
}
void putch(char byte) //Procedimiento para el modulo USART printf
{
	while(PIR1bits.TXIF == 0);
	TXREG = byte;
}

unsigned long HXReadvalue() //Funcion para lectura del modulo HX711
{
	unsigned long value = 0;
	char i = 0;
	HX_SCKpin = 0;
	while(HX_DATpin); //Espera disponibilidad
	for(i = 0; i < 24; i ++) //Solo 25 pulsos Canal A
	{
		HX_SCKpin = 1;
		value <<= 1; //1uS retardo
		HX_SCKpin = 0;
		if(HX_DATpin)
			value ++; //coloca 1 al bit lsb
	}
	HX_SCKpin = 1;
	value ^= 0x800000; //Convierte a un valor absoluto
	HX_SCKpin = 0;
	return value;
}