#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    port = new QSerialPort();
    connect(port, SIGNAL(readyRead()), this, SLOT(readSerialPort()));
    qv1 = new QQuickView();
    qv1->setSource(QUrl::fromLocalFile("../CDC_PICMonitor/QMView1.qml"));
    qv1->show();
    pot1 = qv1->findChild<QObject*>("pot1");
    but1 = qv1->findChild<QObject*>("but1");

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::readSerialPort()
{
    QByteArray databytes;
    if(port->canReadLine())
    {
        databytes = port->readLine();
        QString msg(databytes);
        if(msg.at(0) == 'B')
        {

            ui->lineEdit_2->setText(msg.remove(0,2));
            if(msg.at(0) == '1') but1->setProperty("active", false);
            else but1->setProperty("active", true);
            return;
        }
        if(msg.at(0) == 'V')
        {
            ui->lineEdit->setText(msg.remove(0,2));
            pot1->setProperty("value", msg.toInt());
        }
    }
}
void MainWindow::on_checkBox_stateChanged(int arg1)
{
    if(ui->checkBox->isChecked())
    {
        port->setPortName("/dev/ttyACM0");
        port->setBaudRate(port->Baud9600, port->Input);
        port->setFlowControl(port->NoFlowControl);
        if(port->open(QIODevice::ReadOnly))
            ui->statusbar->showMessage("Puerto Conectado", 0);
        else
            ui->statusbar->showMessage("Error de conexion", 0);

    }
    else
    {
        if(port->isOpen())
        {
            port->close();
            ui->statusbar->showMessage("Puerto Desconectado", 5000);
        }
    }
}
